import React, { useState } from "react";
import { api } from "../api/client";

const ImageUploader = () => {
  const [image, setImage] = useState<File | null>(null);
  const [mask, setMask] = useState<string | null>(null);

  const handleUpload = async () => {
    if (!image) return;
    const formData = new FormData();
    formData.append("file", image);
    const res = await api.post("/segment", formData, { responseType: "arraybuffer" });
    const blob = new Blob([res.data], { type: "image/png" });
    setMask(URL.createObjectURL(blob));
  };

  return (
    <div style={{ textAlign: "center", marginTop: "2rem" }}>
      <input type="file" onChange={(e) => e.target.files && setImage(e.target.files[0])} />
      <button onClick={handleUpload} style={{ marginLeft: "1rem" }}>Segment</button>
      <div style={{ marginTop: "1rem" }}>
        {image && <img src={URL.createObjectURL(image)} width="400" />}
        {mask && (
          <>
            <h3>Mask:</h3>
            <img src={mask} width="400" />
          </>
        )}
      </div>
    </div>
  );
};

export default ImageUploader;
